<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../models/Database.php';
require_once __DIR__ . '/../models/Auth.php';

Auth::checkAccess();

$database = new Database();
$db = $database->getConnection();

// Configuración (fila única)
$config = [
    'nombre_negocio' => 'AbdiSoft POS',
    'moneda' => 'Bs',
    'usa_vencimientos' => true,
];

try {
    $stmtCfg = $db->query("SELECT nombre_negocio, moneda, usa_vencimientos FROM configuracion ORDER BY updated_at DESC LIMIT 1");
    $rowCfg = $stmtCfg->fetch();
    if ($rowCfg) {
        $config['nombre_negocio'] = (string)$rowCfg['nombre_negocio'];
        $config['moneda'] = (string)$rowCfg['moneda'];
        $config['usa_vencimientos'] = (bool)$rowCfg['usa_vencimientos'];
    }
} catch (Throwable $e) {
    // Mantener defaults si la tabla no existe aún o está vacía
}

$nombreNegocio = $config['nombre_negocio'];
$moneda = $config['moneda'];
$usaVencimientos = $config['usa_vencimientos'];

// KPI: Ventas de hoy
$ventasHoy = 0.0;
try {
    $stmt = $db->prepare("SELECT COALESCE(SUM(total),0) AS total_hoy FROM ventas WHERE DATE(fecha) = CURDATE()");
    $stmt->execute();
    $ventasHoy = (float)($stmt->fetch()['total_hoy'] ?? 0);
} catch (Throwable $e) {
}

// KPI: Productos totales (activos)
$productosTotales = 0;
try {
    $stmt = $db->prepare("SELECT COUNT(*) AS c FROM productos WHERE estado = 1");
    $stmt->execute();
    $productosTotales = (int)($stmt->fetch()['c'] ?? 0);
} catch (Throwable $e) {
}

// Alertas: stock bajo
$alertasStock = [];
try {
    $stmt = $db->prepare("
        SELECT id, codigo, nombre, stock_actual, stock_minimo
        FROM productos
        WHERE estado = 1 AND stock_actual <= stock_minimo
        ORDER BY (stock_actual - stock_minimo) ASC, nombre ASC
        LIMIT 200
    ");
    $stmt->execute();
    $alertasStock = $stmt->fetchAll() ?: [];
} catch (Throwable $e) {
}

// Alertas: vencimientos < 30 días (si aplica)
$alertasVencimiento = [];
if ($usaVencimientos) {
    try {
        $stmt = $db->prepare("
            SELECT id, codigo, nombre, fecha_vencimiento, lote, stock_actual
            FROM productos
            WHERE estado = 1
              AND fecha_vencimiento IS NOT NULL
              AND fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
            ORDER BY fecha_vencimiento ASC, nombre ASC
            LIMIT 200
        ");
        $stmt->execute();
        $alertasVencimiento = $stmt->fetchAll() ?: [];
    } catch (Throwable $e) {
    }
}

$alertasCount = count($alertasStock) + count($alertasVencimiento);

$pageTitle = 'Dashboard - AbdiSoft CORE';
$active = 'dashboard';
require_once __DIR__ . '/layout/header.php';
$baseUrl = defined('BASE_URL') ? rtrim((string)BASE_URL, '/') . '/' : '/';
?>

<div class="app-shell">
    <?php require_once __DIR__ . '/layout/sidebar.php'; ?>

    <main class="content">
        <div class="topbar">
            <div>
                <h1 class="h3 title-strong mb-1" style="letter-spacing:-0.6px">Dashboard</h1>
                <div class="meta">
                    <?php echo htmlspecialchars($nombreNegocio); ?> · Usuario: <?php echo htmlspecialchars($_SESSION['user_nombre'] ?? ''); ?>
                </div>
            </div>
            <div class="d-flex gap-2">
                <a class="btn btn-theme-outline" href="<?php echo htmlspecialchars($baseUrl . 'views/modules/inventario.php'); ?>">Ir a Inventario</a>
                <a class="btn btn-primary" href="<?php echo htmlspecialchars($baseUrl . 'views/modules/pos.php'); ?>">Nueva Venta</a>
            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-12 col-lg-4">
                <div class="card p-3 h-100">
                    <div class="card-title">Ventas de Hoy (<?php echo htmlspecialchars($moneda); ?>)</div>
                    <div class="kpi"><?php echo number_format($ventasHoy, 2, '.', ','); ?></div>
                    <div class="text-muted" style="font-size:.9rem">Solo ventas en estado “registrada”.</div>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="card p-3 h-100">
                    <div class="card-title">Productos Totales</div>
                    <div class="kpi"><?php echo number_format($productosTotales, 0, '.', ','); ?></div>
                    <div class="text-muted" style="font-size:.9rem">Activos en inventario.</div>
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="card p-3 h-100 <?php echo $alertasCount > 0 ? 'alert-panel' : ''; ?>">
                    <div class="card-title">Alertas</div>
                    <div class="kpi"><?php echo number_format($alertasCount, 0, '.', ','); ?></div>
                    <div class="text-muted" style="font-size:.9rem">
                        Stock bajo<?php echo $usaVencimientos ? ' + vencimientos próximos' : ''; ?>.
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-12">
                <div class="card p-3 <?php echo count($alertasStock) ? 'alert-panel' : ''; ?>">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div>
                            <h2 class="h5 title-strong mb-1">Alertas de Stock</h2>
                            <div class="text-muted" style="font-size:.9rem">Productos con \(stock\_actual \le stock\_minimo\).</div>
                        </div>
                        <span class="badge"><?php echo count($alertasStock); ?> items</span>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0">
                            <thead>
                            <tr>
                                <th>Código</th>
                                <th>Producto</th>
                                <th class="text-end">Stock</th>
                                <th class="text-end">Mínimo</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if (!count($alertasStock)): ?>
                                <tr><td colspan="4" class="text-muted">Sin alertas de stock por ahora.</td></tr>
                            <?php else: ?>
                                <?php foreach ($alertasStock as $p): ?>
                                    <tr>
                                        <td class="text-heading"><?php echo htmlspecialchars($p['codigo']); ?></td>
                                        <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                                        <td class="text-end text-heading"><?php echo htmlspecialchars((string)$p['stock_actual']); ?></td>
                                        <td class="text-end text-muted"><?php echo htmlspecialchars((string)$p['stock_minimo']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <?php if ($usaVencimientos): ?>
                <div class="col-12">
                    <div class="card p-3 <?php echo count($alertasVencimiento) ? 'warn' : ''; ?>">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <div>
                                <h2 class="h5 title-strong mb-1">Vencimientos Próximos (≤ 30 días)</h2>
                                <div class="text-muted" style="font-size:.9rem">Solo productos con fecha de vencimiento.</div>
                            </div>
                            <span class="badge"><?php echo count($alertasVencimiento); ?> items</span>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-sm align-middle mb-0">
                                <thead>
                                <tr>
                                    <th>Código</th>
                                    <th>Producto</th>
                                    <th>Lote</th>
                                    <th>Vence</th>
                                    <th class="text-end">Stock</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if (!count($alertasVencimiento)): ?>
                                    <tr><td colspan="5" class="text-muted">Sin vencimientos próximos.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($alertasVencimiento as $p): ?>
                                        <tr>
                                            <td class="text-heading"><?php echo htmlspecialchars($p['codigo']); ?></td>
                                            <td><?php echo htmlspecialchars($p['nombre']); ?></td>
                                            <td class="text-muted"><?php echo htmlspecialchars($p['lote'] ?? ''); ?></td>
                                            <td class="text-heading"><?php echo htmlspecialchars($p['fecha_vencimiento']); ?></td>
                                            <td class="text-end text-heading"><?php echo htmlspecialchars((string)$p['stock_actual']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>

