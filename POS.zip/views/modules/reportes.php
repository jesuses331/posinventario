<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../models/Auth.php';
Auth::checkAccess('admin');

$pageTitle = 'Reportes - AbdiSoft CORE';
$active = 'reportes';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$baseUrl = defined('BASE_URL') ? rtrim((string)BASE_URL, '/') . '/' : '/';

$extraJs = [
    'https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js',
];
require_once __DIR__ . '/../layout/header.php';
?>

<div class="app-shell">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>
    <main class="content">
        <h1 class="h4 title-strong mb-3">Reportes de Ventas</h1>

        <div class="card p-3 mb-3">
            <form class="row g-3 align-items-end" id="formRep">
                <div class="col-12 col-md-3">
                    <label class="form-label form-label-compact">Desde</label>
                    <input type="date" class="form-control themed-input" id="r_desde" required>
                </div>
                <div class="col-12 col-md-3">
                    <label class="form-label form-label-compact">Hasta</label>
                    <input type="date" class="form-control themed-input" id="r_hasta" required>
                </div>
                <div class="col-12 col-md-3">
                    <button class="btn btn-primary" type="submit" id="btnGenerar">Generar</button>
                </div>
            </form>
            <div class="alert alert-danger mt-3 d-none" id="repError" style="background: rgba(220,53,69,.1); border-color: #dc3545; color:#ffb3b3;"></div>
        </div>

        <div class="row g-3">
            <div class="col-12 col-lg-6">
                <div class="card p-3 h-100">
                    <h2 class="h6 title-strong mb-2">Ventas por día</h2>
                    <div id="tablaDiasWrapper" class="table-responsive">
                        <table class="table table-sm align-middle mb-0" id="tablaDias">
                            <thead>
                            <tr>
                                <th>Fecha</th>
                                <th class="text-end">#Ventas</th>
                                <th class="text-end">Total</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr><td colspan="3" class="text-muted">Sin datos.</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div class="card p-3 h-100">
                    <h2 class="h6 title-strong mb-2">Top 10 productos</h2>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-0" id="tablaTop">
                            <thead>
                            <tr>
                                <th>Producto</th>
                                <th class="text-end">Unidades</th>
                                <th class="text-end">Importe</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr><td colspan="3" class="text-muted">Sin datos.</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

<script>
(() => {
    const baseUrl = <?php echo json_encode($baseUrl, JSON_UNESCAPED_SLASHES); ?>;
    const apiUrl = baseUrl + 'views/modules/reportes_api.php';
    const rDesde = document.getElementById('r_desde');
    const rHasta = document.getElementById('r_hasta');
    const errorBox = document.getElementById('repError');
    const tbodyDias = document.querySelector('#tablaDias tbody');
    const tbodyTop = document.querySelector('#tablaTop tbody');

    function money(n) { return Number(n || 0).toFixed(2); }
    function escapeHtml(str) {
        return String(str ?? '')
            .replaceAll('&','&amp;')
            .replaceAll('<','&lt;')
            .replaceAll('>','&gt;')
            .replaceAll('"','&quot;')
            .replaceAll("'","&#039;");
    }
    function showErr(msg) {
        errorBox.textContent = msg || 'Error';
        errorBox.classList.remove('d-none');
    }
    function clearErr() {
        errorBox.classList.add('d-none');
        errorBox.textContent = '';
    }

    // Valores por defecto: hoy
    const hoy = new Date().toISOString().slice(0,10);
    rDesde.value = hoy;
    rHasta.value = hoy;

    document.getElementById('formRep').addEventListener('submit', async (ev) => {
        ev.preventDefault();
        clearErr();
        const d = rDesde.value;
        const h = rHasta.value;
        if (!d || !h) {
            showErr('Selecciona el rango de fechas.');
            return;
        }

        const btn = document.getElementById('btnGenerar');
        btn.disabled = true;
        btn.textContent = 'Cargando...';
        tbodyDias.innerHTML = '<tr><td colspan="3" class="text-muted">Cargando...</td></tr>';
        tbodyTop.innerHTML = '<tr><td colspan="3" class="text-muted">Cargando...</td></tr>';

        try {
            const url = apiUrl + '?action=ventas&desde=' + encodeURIComponent(d) + '&hasta=' + encodeURIComponent(h);
            const res = await fetch(url, { credentials: 'same-origin' });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message || 'Error');

            const dias = json.dias || [];
            const top = json.top || [];

            if (!dias.length) {
                tbodyDias.innerHTML = '<tr><td colspan="3" class="text-muted">Sin ventas en el rango.</td></tr>';
            } else {
                tbodyDias.innerHTML = '';
                for (const d of dias) {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${escapeHtml(d.dia)}</td>
                        <td class="text-end">${escapeHtml(d.num_ventas)}</td>
                        <td class="text-end">${money(d.total)}</td>
                    `;
                    tbodyDias.appendChild(tr);
                }
            }

            if (!top.length) {
                tbodyTop.innerHTML = '<tr><td colspan="3" class="text-muted">Sin datos.</td></tr>';
            } else {
                tbodyTop.innerHTML = '';
                for (const t of top) {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>
                            <div class="text-heading" style="font-weight:700">${escapeHtml(t.nombre)}</div>
                            <div class="text-muted" style="font-size:.85rem">${escapeHtml(t.codigo)}</div>
                        </td>
                        <td class="text-end">${escapeHtml(t.unidades)}</td>
                        <td class="text-end">${money(t.importe)}</td>
                    `;
                    tbodyTop.appendChild(tr);
                }
            }
        } catch (e) {
            showErr(e.message || 'Error generando reporte');
        } finally {
            btn.disabled = false;
            btn.textContent = 'Generar';
        }
    });
})();
</script>


