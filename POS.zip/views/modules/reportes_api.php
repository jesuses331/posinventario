<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../models/Database.php';
require_once __DIR__ . '/../../models/Auth.php';

Auth::checkAccess('admin');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function json_out_rep(int $code, array $payload): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit();
}

try {
    $db = (new Database())->getConnection();
} catch (Throwable $e) {
    json_out_rep(500, ['ok' => false, 'message' => 'Error de conexión.']);
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'ventas';

if ($action === 'ventas') {
    $desde = (string)($_GET['desde'] ?? '');
    $hasta = (string)($_GET['hasta'] ?? '');

    if ($desde === '' || $hasta === '') {
        json_out_rep(422, ['ok' => false, 'message' => 'Rango de fechas requerido.']);
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $desde) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $hasta)) {
        json_out_rep(422, ['ok' => false, 'message' => 'Formato de fecha inválido.']);
    }

    $stmt = $db->prepare("
        SELECT DATE(fecha) AS dia, COUNT(*) AS num_ventas, SUM(total) AS total
        FROM ventas
        WHERE DATE(fecha) BETWEEN :d AND :h
        GROUP BY DATE(fecha)
        ORDER BY DATE(fecha) ASC
    ");
    $stmt->execute([':d' => $desde, ':h' => $hasta]);
    $dias = $stmt->fetchAll() ?: [];

    $stmtTop = $db->prepare("
        SELECT p.id, p.codigo, p.nombre,
               SUM(vd.cantidad) AS unidades,
               SUM(vd.subtotal) AS importe
        FROM ventas_detalle vd
        INNER JOIN ventas v ON v.id = vd.venta_id
        INNER JOIN productos p ON p.id = vd.producto_id
        WHERE DATE(v.fecha) BETWEEN :d AND :h
        GROUP BY p.id, p.codigo, p.nombre
        ORDER BY unidades DESC
        LIMIT 10
    ");
    $stmtTop->execute([':d' => $desde, ':h' => $hasta]);
    $top = $stmtTop->fetchAll() ?: [];

    json_out_rep(200, ['ok' => true, 'dias' => $dias, 'top' => $top]);
}

json_out_rep(400, ['ok' => false, 'message' => 'Acción inválida.']);

