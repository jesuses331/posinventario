<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../models/Database.php';
require_once __DIR__ . '/../../models/Auth.php';
Auth::checkAccess();

$pageTitle = 'Nueva Venta (POS) - AbdiSoft CORE';
$active = 'pos';
$baseUrl = defined('BASE_URL') ? rtrim((string)BASE_URL, '/') . '/' : '/';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

// Config (fila única)
$moneda = 'Bs';
try {
    $db = (new Database())->getConnection();
    $stmtCfg = $db->query("SELECT moneda FROM configuracion ORDER BY updated_at DESC LIMIT 1");
    $rowCfg = $stmtCfg->fetch();
    if ($rowCfg && isset($rowCfg['moneda'])) {
        $moneda = (string)$rowCfg['moneda'];
    }
} catch (Throwable $e) {
}

$extraJs = [
    'https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js',
];
require_once __DIR__ . '/../layout/header.php';
?>

<div class="app-shell">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>
    <main class="content">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <div>
                <h1 class="h4 title-strong mb-1">Nueva Venta (POS)</h1>
                <div class="text-muted" style="font-size:.92rem">Búsqueda por código o nombre · rápido · seguro.</div>
            </div>
            <button class="btn btn-theme-outline" id="btnLimpiar" type="button">Limpiar</button>
        </div>

        <div class="row g-3">
            <div class="col-12 col-lg-4">
                <div class="card p-3">
                    <label class="form-label form-label-compact">Buscar producto</label>
                    <div class="input-group">
                        <input class="form-control themed-input" id="q" placeholder="Ej: PARACETAMOL o 12345">
                        <button class="btn btn-primary" id="btnBuscar" type="button">Buscar</button>
                    </div>
                    <div class="text-muted mt-2" style="font-size:.85rem" id="hint">Escribe y presiona Enter.</div>

                    <div class="mt-3" id="resultados"></div>
                </div>
            </div>

            <div class="col-12 col-lg-4">
                <div class="card p-3">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div>
                            <div class="form-label-compact">Lista de Productos</div>
                            <div class="text-muted" style="font-size:.9rem">Agregar al carrito</div>
                        </div>
                        <input class="form-control form-control-sm themed-input" id="searchProductos" placeholder="Buscar en lista..." style="width:120px;">
                    </div>

                    <div class="table-responsive" style="max-height: 50vh; overflow:auto;">
                        <table class="table table-sm align-middle mb-0">
                            <thead>
                            <tr>
                                <th>Producto</th>
                                <th class="text-end">Precio</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody id="productosBody">
                            <tr><td colspan="3" class="text-muted">Cargando...</td></tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <div class="text-muted" style="font-size:.85rem" id="paginationInfo">Página 1 de 1</div>
                        <div>
                            <button class="btn btn-sm btn-theme-outline" id="btnPrev" disabled>&laquo;</button>
                            <button class="btn btn-sm btn-theme-outline" id="btnNext"> &raquo;</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-lg-4">
                <div class="card p-3">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <div>
                            <div class="form-label-compact">Carrito</div>
                            <div class="text-muted" style="font-size:.9rem">Items: <span id="itemsCount">0</span></div>
                        </div>
                        <div class="text-end">
                            <div class="form-label-compact">Total (<?php echo htmlspecialchars($moneda); ?>)</div>
                            <div class="kpi" id="total">0.00</div>
                        </div>
                    </div>

                    <div class="table-responsive" style="max-height: 52vh; overflow:auto;">
                        <table class="table table-sm align-middle mb-0">
                            <thead>
                            <tr>
                                <th>Producto</th>
                                <th class="text-end">Cant</th>
                                <th class="text-end">P.Unit</th>
                                <th class="text-end">Sub</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody id="carritoBody">
                            <tr><td colspan="5" class="text-muted">Sin productos.</td></tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="alert alert-danger mt-3 d-none" id="posError" style="background: rgba(220,53,69,.1); border-color: #dc3545; color:#ffb3b3;"></div>
                    <div class="d-grid mt-3">
                        <button class="btn btn-primary btn-lg" id="btnCobrar" type="button">Cobrar</button>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

<script>
(() => {
    const baseUrl = <?php echo json_encode($baseUrl, JSON_UNESCAPED_SLASHES); ?>;
    const apiUrl = baseUrl + 'views/modules/pos_api.php';
    const csrfToken = <?php echo json_encode($csrfToken, JSON_UNESCAPED_SLASHES); ?>;
    const moneda = <?php echo json_encode($moneda, JSON_UNESCAPED_UNICODE); ?>;

    const q = document.getElementById('q');
    const resultados = document.getElementById('resultados');
    const productosBody = document.getElementById('productosBody');
    const searchProductos = document.getElementById('searchProductos');
    const paginationInfo = document.getElementById('paginationInfo');
    const btnPrev = document.getElementById('btnPrev');
    const btnNext = document.getElementById('btnNext');
    const carritoBody = document.getElementById('carritoBody');
    const totalEl = document.getElementById('total');
    const itemsCountEl = document.getElementById('itemsCount');
    const posError = document.getElementById('posError');

    let carrito = []; // {producto_id,codigo,nombre,precio_venta,stock_actual,cantidad}
    let currentPage = 1;
    let totalPages = 1;
    let currentSearch = '';

    function money(n) {
        const x = Number(n || 0);
        return x.toFixed(2);
    }
    function showError(msg) {
        posError.textContent = msg || 'Error';
        posError.classList.remove('d-none');
    }
    function clearError() {
        posError.classList.add('d-none');
        posError.textContent = '';
    }

    function calc() {
        let total = 0;
        let items = 0;
        for (const it of carrito) {
            total += Number(it.precio_venta) * Number(it.cantidad);
            items += 1;
        }
        totalEl.textContent = money(total);
        itemsCountEl.textContent = String(items);
    }

    function renderCarrito() {
        carritoBody.innerHTML = '';
        if (!carrito.length) {
            carritoBody.innerHTML = `<tr><td colspan="5" class="text-muted">Sin productos.</td></tr>`;
            calc();
            return;
        }

        for (const it of carrito) {
            const sub = Number(it.precio_venta) * Number(it.cantidad);
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>
                    <div class="text-heading" style="font-weight:700">${escapeHtml(it.nombre)}</div>
                    <div class="text-muted" style="font-size:.85rem">${escapeHtml(it.codigo)} · stock: ${escapeHtml(String(it.stock_actual))}</div>
                </td>
                <td class="text-end">
                    <input type="number" step="1" min="1" class="form-control form-control-sm themed-input qty qty-input"
                           value="${escapeHtml(String(it.cantidad))}">
                </td>
                <td class="text-end text-heading">${money(it.precio_venta)}</td>
                <td class="text-end text-heading">${money(sub)}</td>
                <td class="text-end">
                    <button class="btn btn-sm btn-theme-outline del">X</button>
                </td>
            `;
            tr.querySelector('.del').addEventListener('click', () => {
                carrito = carrito.filter(x => x.producto_id !== it.producto_id);
                renderCarrito();
            });
            tr.querySelector('.qty').addEventListener('change', (ev) => {
                const v = Number(ev.target.value || 1);
                it.cantidad = Math.max(1, Math.floor(v));
                renderCarrito();
            });
            carritoBody.appendChild(tr);
        }
        calc();
    }

    async function loadProductos(page = 1, search = '') {
        productosBody.innerHTML = `<tr><td colspan="3" class="text-muted">Cargando...</td></tr>`;
        try {
            const url = baseUrl + 'views/modules/productos_api.php?action=list_for_pos&page=' + page + '&per_page=10&search=' + encodeURIComponent(search);
            const res = await fetch(url, { credentials: 'same-origin' });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message || 'Error cargando productos');

            const rows = json.data || [];
            const pagination = json.pagination || {};

            productosBody.innerHTML = '';
            if (!rows.length) {
                productosBody.innerHTML = `<tr><td colspan="3" class="text-muted">Sin productos.</td></tr>`;
                return;
            }

            for (const p of rows) {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>
                        <div class="text-heading" style="font-weight:700">${escapeHtml(p.nombre)}</div>
                        <div class="text-muted" style="font-size:.85rem">${escapeHtml(p.codigo)} · stock: ${escapeHtml(String(p.stock_actual))}</div>
                    </td>
                    <td class="text-end text-heading">${money(p.precio_venta)}</td>
                    <td class="text-end">
                        <button class="btn btn-sm btn-primary add-to-cart">Agregar</button>
                    </td>
                `;
                tr.querySelector('.add-to-cart').addEventListener('click', () => {
                    const existing = carrito.find(x => x.producto_id == p.id);
                    if (existing) {
                        existing.cantidad += 1;
                    } else {
                        carrito.push({
                            producto_id: Number(p.id),
                            codigo: p.codigo,
                            nombre: p.nombre,
                            precio_venta: Number(p.precio_venta),
                            stock_actual: Number(p.stock_actual),
                            cantidad: 1
                        });
                    }
                    renderCarrito();
                });
                productosBody.appendChild(tr);
            }

            currentPage = pagination.page || 1;
            totalPages = pagination.total_pages || 1;
            paginationInfo.textContent = `Página ${currentPage} de ${totalPages}`;
            btnPrev.disabled = currentPage <= 1;
            btnNext.disabled = currentPage >= totalPages;
        } catch (e) {
            productosBody.innerHTML = `<tr><td colspan="3" class="text-muted">Error cargando productos.</td></tr>`;
            console.error(e);
        }
    }

    function escapeHtml(str) {
        return String(str ?? '')
            .replaceAll('&','&amp;')
            .replaceAll('<','&lt;')
            .replaceAll('>','&gt;')
            .replaceAll('"','&quot;')
            .replaceAll("'","&#039;");
    }

    async function buscar() {
        clearError();
        const term = q.value.trim();
        if (!term) return;
        resultados.innerHTML = `<div class="text-muted">Buscando...</div>`;

        try {
            const res = await fetch(apiUrl + '?action=search_products&q=' + encodeURIComponent(term), { credentials: 'same-origin' });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message || 'Error buscando');

            const rows = json.data || [];
            if (!rows.length) {
                resultados.innerHTML = `<div class="text-muted">Sin resultados.</div>`;
                return;
            }

            const list = document.createElement('div');
            list.className = 'd-grid gap-2';

            for (const p of rows) {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'btn pos-product-item text-start';
                btn.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-heading" style="font-weight:700">${escapeHtml(p.nombre)}</div>
                            <div class="text-muted" style="font-size:.85rem">${escapeHtml(p.codigo)} · stock: ${escapeHtml(String(p.stock_actual))}</div>
                        </div>
                        <div class="text-end">
                            <div class="text-muted" style="font-size:.8rem">${escapeHtml(moneda)}</div>
                            <div class="text-heading" style="font-weight:800">${money(p.precio_venta)}</div>
                        </div>
                    </div>
                `;
                btn.addEventListener('click', () => {
                    const existing = carrito.find(x => x.producto_id == p.id);
                    if (existing) {
                        existing.cantidad += 1;
                    } else {
                        carrito.push({
                            producto_id: Number(p.id),
                            codigo: p.codigo,
                            nombre: p.nombre,
                            precio_venta: Number(p.precio_venta),
                            stock_actual: Number(p.stock_actual),
                            cantidad: 1
                        });
                    }
                    renderCarrito();
                });
                list.appendChild(btn);
            }
            resultados.innerHTML = '';
            resultados.appendChild(list);
        } catch (e) {
            resultados.innerHTML = '';
            showError(e.message || 'Error');
        }
    }

    document.getElementById('btnBuscar').addEventListener('click', buscar);
    q.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') {
            ev.preventDefault();
            buscar();
        }
    });

    searchProductos.addEventListener('input', (ev) => {
        currentSearch = ev.target.value.trim();
        loadProductos(1, currentSearch);
    });

    btnPrev.addEventListener('click', () => {
        if (currentPage > 1) {
            loadProductos(currentPage - 1, currentSearch);
        }
    });

    btnNext.addEventListener('click', () => {
        if (currentPage < totalPages) {
            loadProductos(currentPage + 1, currentSearch);
        }
    });

    document.getElementById('btnLimpiar').addEventListener('click', () => {
        clearError();
        carrito = [];
        resultados.innerHTML = '';
        q.value = '';
        renderCarrito();
        q.focus();
    });

    document.getElementById('btnCobrar').addEventListener('click', async () => {
        clearError();
        if (!carrito.length) {
            showError('Carrito vacío.');
            return;
        }

        const items = carrito.map(it => ({ producto_id: it.producto_id, cantidad: it.cantidad }));

        const btn = document.getElementById('btnCobrar');
        btn.disabled = true;
        btn.textContent = 'Procesando...';

        try {
            const res = await fetch(apiUrl + '?action=create_sale', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken
                },
                credentials: 'same-origin',
                body: JSON.stringify({ items })
            });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message || 'Error cobrando');

            alert(`Venta #${json.venta_id} registrada. Total: ${moneda} ${money(json.total)}`);
            carrito = [];
            renderCarrito();
            resultados.innerHTML = '';
            q.value = '';
            q.focus();
        } catch (e) {
            showError(e.message || 'Error');
        } finally {
            btn.disabled = false;
            btn.textContent = 'Cobrar';
        }
    });

    renderCarrito();
    loadProductos();
    q.focus();
})();
</script>

