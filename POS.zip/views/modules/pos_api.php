<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../models/Database.php';
require_once __DIR__ . '/../../models/Auth.php';

Auth::checkAccess(); // admin o cajero

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function json_out(int $code, array $payload): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit();
}

function require_csrf(): void {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');
    if (!isset($_SESSION['csrf_token']) || !is_string($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        json_out(403, ['ok' => false, 'message' => 'CSRF inválido.']);
    }
}

try {
    $db = (new Database())->getConnection();
} catch (Throwable $e) {
    json_out(500, ['ok' => false, 'message' => 'No se pudo conectar a la base de datos.']);
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'search_products') {
    $q = trim((string)($_GET['q'] ?? ''));
    if ($q === '') {
        json_out(200, ['ok' => true, 'data' => []]);
    }

    $stmt = $db->prepare("
        SELECT id, codigo, nombre, precio_venta, stock_actual
        FROM productos
        WHERE estado = 1
          AND (codigo LIKE :q_codigo OR nombre LIKE :q_nombre)
        ORDER BY nombre ASC
        LIMIT 20
    ");
    $searchTerm = '%' . $q . '%';
    $stmt->execute([
        ':q_codigo' => $searchTerm,
        ':q_nombre' => $searchTerm,
    ]);
    $rows = $stmt->fetchAll() ?: [];
    json_out(200, ['ok' => true, 'data' => $rows]);
}

if ($action === 'create_sale') {
    require_csrf();

    $usuarioId = (int)($_SESSION['user_id'] ?? 0);
    if ($usuarioId <= 0) {
        json_out(401, ['ok' => false, 'message' => 'Sesión inválida.']);
    }

    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);
    if (!is_array($payload)) {
        json_out(400, ['ok' => false, 'message' => 'JSON inválido.']);
    }

    $items = $payload['items'] ?? null;
    if (!is_array($items) || count($items) === 0) {
        json_out(422, ['ok' => false, 'message' => 'Agrega al menos 1 producto.']);
    }

    $clean = [];
    foreach ($items as $it) {
        $pid = (int)($it['producto_id'] ?? 0);
        $qty = (float)($it['cantidad'] ?? 0);
        if ($pid <= 0 || $qty <= 0) {
            json_out(422, ['ok' => false, 'message' => 'Items inválidos.']);
        }
        $clean[] = ['producto_id' => $pid, 'cantidad' => $qty];
    }

    // Unificar por producto (si se repite)
    $byId = [];
    foreach ($clean as $it) {
        $pid = $it['producto_id'];
        $byId[$pid] = ($byId[$pid] ?? 0) + $it['cantidad'];
    }

    $productoIds = array_keys($byId);
    $placeholders = implode(',', array_fill(0, count($productoIds), '?'));

    try {
        $db->beginTransaction();

        // Bloquear filas para evitar venta concurrente sin stock
        $stmtP = $db->prepare("
            SELECT id, codigo, nombre, precio_venta, stock_actual
            FROM productos
            WHERE id IN ($placeholders) AND estado = 1
            FOR UPDATE
        ");
        $stmtP->execute($productoIds);
        $productos = $stmtP->fetchAll() ?: [];

        if (count($productos) !== count($productoIds)) {
            $db->rollBack();
            json_out(409, ['ok' => false, 'message' => 'Uno o más productos no existen o están inactivos.']);
        }

        $total = 0.0;
        $detalle = [];
        foreach ($productos as $p) {
            $pid = (int)$p['id'];
            $qty = (float)$byId[$pid];
            $stock = (float)$p['stock_actual'];
            if ($qty > $stock) {
                $db->rollBack();
                json_out(409, ['ok' => false, 'message' => "Stock insuficiente: {$p['codigo']} - {$p['nombre']} (stock: {$p['stock_actual']})."]);
            }
            $precio = (float)$p['precio_venta'];
            $sub = $precio * $qty;
            $total += $sub;
            $detalle[] = [
                'producto_id' => $pid,
                'cantidad' => $qty,
                'precio_unitario' => $precio,
                'subtotal' => $sub,
            ];
        }

        // Insert venta (schema actual: ventas(id,total,usuario_id,fecha))
        $stmtV = $db->prepare("INSERT INTO ventas (total, usuario_id, fecha) VALUES (:total, :usuario_id, NOW())");
        $stmtV->execute([':total' => $total, ':usuario_id' => $usuarioId]);
        $ventaId = (int)$db->lastInsertId();

        $stmtD = $db->prepare("
            INSERT INTO ventas_detalle (venta_id, producto_id, cantidad, precio_unitario, subtotal)
            VALUES (:venta_id, :producto_id, :cantidad, :precio_unitario, :subtotal)
        ");
        $stmtU = $db->prepare("UPDATE productos SET stock_actual = stock_actual - :cantidad WHERE id = :id LIMIT 1");

        foreach ($detalle as $d) {
            $stmtD->execute([
                ':venta_id' => $ventaId,
                ':producto_id' => $d['producto_id'],
                ':cantidad' => $d['cantidad'],
                ':precio_unitario' => $d['precio_unitario'],
                ':subtotal' => $d['subtotal'],
            ]);
            $stmtU->execute([':cantidad' => $d['cantidad'], ':id' => $d['producto_id']]);
        }

        $db->commit();
        json_out(201, ['ok' => true, 'message' => 'Venta registrada.', 'venta_id' => $ventaId, 'total' => $total]);
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        json_out(500, ['ok' => false, 'message' => 'Error registrando venta.']);
    }
}

json_out(400, ['ok' => false, 'message' => 'Acción inválida.']);

