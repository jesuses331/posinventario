<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../models/Database.php';
require_once __DIR__ . '/../../models/Auth.php';
require_once __DIR__ . '/../../models/Producto.php';

Auth::checkAccess('admin');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function json_out(int $code, array $payload): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit();
}

function require_csrf(): void {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf_token'] ?? '');
    if (!isset($_SESSION['csrf_token']) || !is_string($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        json_out(403, ['ok' => false, 'message' => 'CSRF inválido.']);
    }
}

try {
    $db = (new Database())->getConnection();
    $producto = new Producto($db);
} catch (Throwable $e) {
    json_out(500, ['ok' => false, 'message' => 'No se pudo conectar a la base de datos.']);
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

if ($action === 'list_for_pos') {
    // Permitir cajeros para esta acción
    if (!isset($_SESSION['user_id'])) {
        json_out(403, ['ok' => false, 'message' => 'Acceso denegado.']);
    }
    try {
        $page = (int)($_GET['page'] ?? 1);
        $perPage = (int)($_GET['per_page'] ?? 10);
        $search = trim((string)($_GET['search'] ?? ''));

        if ($page < 1) $page = 1;
        if ($perPage < 1 || $perPage > 100) $perPage = 10;

        $offset = ($page - 1) * $perPage;

        $total = $producto->countAll($search);
        $rows = $producto->listSimple($offset, $perPage, $search, 'nombre', 'asc');

        $totalPages = ceil($total / $perPage);

        json_out(200, [
            'ok' => true,
            'data' => $rows,
            'pagination' => [
                'page' => $page,
                'per_page' => $perPage,
                'total' => $total,
                'total_pages' => $totalPages,
            ],
        ]);
    } catch (Throwable $e) {
        json_out(500, ['ok' => false, 'message' => 'Error interno del servidor: ' . $e->getMessage()]);
    }
}

if ($action === 'list') {
    try {
        $draw = (int)($_GET['draw'] ?? 0);
        $start = (int)($_GET['start'] ?? 0);
        $length = (int)($_GET['length'] ?? 25);
        $search = (string)(($_GET['search']['value'] ?? '') ?: '');

        $columns = [
            0 => 'id',
            1 => 'codigo',
            2 => 'nombre',
            3 => 'precio_compra',
            4 => 'precio_venta',
            5 => 'stock_actual',
            6 => 'stock_minimo',
            7 => 'fecha_vencimiento',
            8 => 'estado',
        ];
        $orderIdx = (int)($_GET['order'][0]['column'] ?? 0);
        $orderBy = $columns[$orderIdx] ?? 'id';
        $orderDir = (string)($_GET['order'][0]['dir'] ?? 'desc');

        $recordsTotal = $producto->countAll('');
        $recordsFiltered = $producto->countAll($search);
        $rows = $producto->listDataTables($start, $length, $search, $orderBy, $orderDir);

        json_out(200, [
            'draw' => $draw,
            'recordsTotal' => $recordsTotal,
            'recordsFiltered' => $recordsFiltered,
            'data' => $rows,
        ]);
    } catch (Throwable $e) {
        json_out(500, [
            'draw' => (int)($_GET['draw'] ?? 0),
            'recordsTotal' => 0,
            'recordsFiltered' => 0,
            'data' => [],
            'error' => 'Error interno del servidor: ' . $e->getMessage(),
        ]);
    }
}

if ($action === 'list_for_pos') {
    $page = (int)($_GET['page'] ?? 1);
    $perPage = (int)($_GET['per_page'] ?? 10);
    $search = trim((string)($_GET['search'] ?? ''));

    if ($page < 1) $page = 1;
    if ($perPage < 1 || $perPage > 100) $perPage = 10;

    $offset = ($page - 1) * $perPage;

    $total = $producto->countAll($search);
    $rows = $producto->listSimple($offset, $perPage, $search, 'nombre', 'asc');

    $totalPages = ceil($total / $perPage);

    json_out(200, [
        'ok' => true,
        'data' => $rows,
        'pagination' => [
            'page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
        ],
    ]);
}

if ($action === 'get') {
    try {
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            json_out(400, ['ok' => false, 'message' => 'ID inválido.']);
        }
        $row = $producto->findById($id);
        if (!$row) {
            json_out(404, ['ok' => false, 'message' => 'Producto no encontrado.']);
        }
        json_out(200, ['ok' => true, 'data' => $row]);
    } catch (Throwable $e) {
        json_out(500, ['ok' => false, 'message' => 'Error interno del servidor: ' . $e->getMessage()]);
    }
}

if ($action === 'save') {
    require_csrf();
    try {
        $id = (int)($_POST['id'] ?? 0);
        $codigo = trim((string)($_POST['codigo'] ?? ''));
        $nombre = trim((string)($_POST['nombre'] ?? ''));
        $precioCompra = (float)($_POST['precio_compra'] ?? 0);
        $precioVenta = (float)($_POST['precio_venta'] ?? 0);
        $stockActual = (float)($_POST['stock_actual'] ?? 0);
        $stockMinimo = (float)($_POST['stock_minimo'] ?? 0);
        $factor = (int)($_POST['factor_conversion'] ?? 1);
        $fechaV = trim((string)($_POST['fecha_vencimiento'] ?? ''));
        $lote = trim((string)($_POST['lote'] ?? ''));
        $estado = (int)($_POST['estado'] ?? 1);

        if ($codigo === '' || $nombre === '') {
            json_out(422, ['ok' => false, 'message' => 'Código y nombre son obligatorios.']);
        }
        if ($factor <= 0) $factor = 1;
        if ($estado !== 0) $estado = 1;
        $fechaDb = $fechaV === '' ? null : $fechaV;
        if ($fechaDb !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fechaDb)) {
            json_out(422, ['ok' => false, 'message' => 'Fecha de vencimiento inválida (formato YYYY-MM-DD).']);
        }

        $payload = [
            'codigo' => $codigo,
            'nombre' => $nombre,
            'precio_compra' => $precioCompra,
            'precio_venta' => $precioVenta,
            'stock_actual' => $stockActual,
            'stock_minimo' => $stockMinimo,
            'factor_conversion' => $factor,
            'fecha_vencimiento' => $fechaDb,
            'lote' => $lote === '' ? null : $lote,
            'estado' => $estado,
        ];

        if ($id > 0) {
            $producto->update($id, $payload);
            json_out(200, ['ok' => true, 'message' => 'Producto actualizado.']);
        }
        $newId = $producto->create($payload);
        json_out(201, ['ok' => true, 'message' => 'Producto creado.', 'id' => $newId]);
    } catch (PDOException $e) {
        // 1062 = duplicate key
        if ((int)($e->errorInfo[1] ?? 0) === 1062) {
            json_out(409, ['ok' => false, 'message' => 'Código ya existe.']);
        }
        json_out(500, ['ok' => false, 'message' => 'Error guardando producto.']);
    } catch (Throwable $e) {
        json_out(500, ['ok' => false, 'message' => 'Error guardando producto.']);
    }
}

json_out(400, ['ok' => false, 'message' => 'Acción inválida.']);

