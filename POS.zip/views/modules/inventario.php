<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../models/Auth.php';
Auth::checkAccess('admin');

$pageTitle = 'Inventario - AbdiSoft CORE';
$active = 'inventario';
$baseUrl = defined('BASE_URL') ? rtrim((string)BASE_URL, '/') . '/' : '/';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

$extraCss = [
    'https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css',
];
$extraJs = [
    'https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js',
    'https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js',
    'https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js',
];
require_once __DIR__ . '/../layout/header.php';
?>

<div class="app-shell">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>
    <main class="content">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <div>
                <h1 class="h4 title-strong mb-1">Inventario</h1>
                <div class="text-muted" style="font-size:.92rem">Búsqueda rápida + edición en modal (Admin).</div>
            </div>
            <button class="btn btn-primary" type="button" id="btnNuevo">Nuevo Producto</button>
        </div>

        <div class="card p-3">
            <div class="table-responsive">
                <table id="tablaProductos" class="table table-sm table-hover align-middle mb-0" style="width:100%">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Código</th>
                        <th>Producto</th>
                        <th class="text-end">Compra</th>
                        <th class="text-end">Venta</th>
                        <th class="text-end">Stock</th>
                        <th class="text-end">Mín</th>
                        <th>Vence</th>
                        <th>Estado</th>
                        <th style="width:120px">Acciones</th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
    </main>
</div>

<!-- Modal Producto -->
<div class="modal fade modal-themed" id="modalProducto" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Producto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <form id="formProducto">
                <div class="modal-body">
                    <input type="hidden" name="id" id="p_id" value="0">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">

                    <div class="row g-3">
                        <div class="col-12 col-md-4">
                            <label class="form-label form-label-compact">Código</label>
                            <input class="form-control themed-input" name="codigo" id="p_codigo" required>
                        </div>
                        <div class="col-12 col-md-8">
                            <label class="form-label form-label-compact">Nombre</label>
                            <input class="form-control themed-input" name="nombre" id="p_nombre" required>
                        </div>

                        <div class="col-12 col-md-3">
                            <label class="form-label form-label-compact">Compra</label>
                            <input type="number" step="0.01" class="form-control themed-input" name="precio_compra" id="p_compra" value="0">
                        </div>
                        <div class="col-12 col-md-3">
                            <label class="form-label form-label-compact">Venta</label>
                            <input type="number" step="0.01" class="form-control themed-input" name="precio_venta" id="p_venta" value="0">
                        </div>
                        <div class="col-12 col-md-3">
                            <label class="form-label form-label-compact">Stock</label>
                            <input type="number" step="0.001" class="form-control themed-input" name="stock_actual" id="p_stock" value="0">
                        </div>
                        <div class="col-12 col-md-3">
                            <label class="form-label form-label-compact">Stock mín</label>
                            <input type="number" step="0.001" class="form-control themed-input" name="stock_minimo" id="p_min" value="0">
                        </div>

                        <div class="col-12 col-md-3">
                            <label class="form-label form-label-compact">Factor</label>
                            <input type="number" class="form-control themed-input" name="factor_conversion" id="p_factor" value="1" min="1">
                        </div>
                        <div class="col-12 col-md-3">
                            <label class="form-label form-label-compact">Vence</label>
                            <input type="date" class="form-control themed-input" name="fecha_vencimiento" id="p_vence">
                        </div>
                        <div class="col-12 col-md-4">
                            <label class="form-label form-label-compact">Lote</label>
                            <input class="form-control themed-input" name="lote" id="p_lote">
                        </div>
                        <div class="col-12 col-md-2">
                            <label class="form-label form-label-compact">Estado</label>
                            <select class="form-select themed-input" name="estado" id="p_estado">
                                <option value="1">Activo</option>
                                <option value="0">Inactivo</option>
                            </select>
                        </div>
                    </div>

                    <div class="alert alert-danger mt-3 d-none" id="formError" style="background: rgba(220,53,69,.1); border-color: #dc3545; color:#ffb3b3;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-theme-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="btnGuardar">Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layout/footer.php'; ?>

<script>
(() => {
    const baseUrl = <?php echo json_encode($baseUrl, JSON_UNESCAPED_SLASHES); ?>;
    const csrfToken = <?php echo json_encode($csrfToken, JSON_UNESCAPED_SLASHES); ?>;
    const apiUrl = baseUrl + 'views/modules/productos_api.php';

    const modalEl = document.getElementById('modalProducto');
    const modal = new bootstrap.Modal(modalEl);
    const form = document.getElementById('formProducto');
    const formError = document.getElementById('formError');

    function showError(msg) {
        formError.textContent = msg || 'Error';
        formError.classList.remove('d-none');
    }
    function clearError() {
        formError.classList.add('d-none');
        formError.textContent = '';
    }

    function fillForm(data) {
        document.getElementById('p_id').value = data?.id ?? 0;
        document.getElementById('p_codigo').value = data?.codigo ?? '';
        document.getElementById('p_nombre').value = data?.nombre ?? '';
        document.getElementById('p_compra').value = data?.precio_compra ?? 0;
        document.getElementById('p_venta').value = data?.precio_venta ?? 0;
        document.getElementById('p_stock').value = data?.stock_actual ?? 0;
        document.getElementById('p_min').value = data?.stock_minimo ?? 0;
        document.getElementById('p_factor').value = data?.factor_conversion ?? 1;
        document.getElementById('p_vence').value = data?.fecha_vencimiento ?? '';
        document.getElementById('p_lote').value = data?.lote ?? '';
        document.getElementById('p_estado').value = (data?.estado ?? 1).toString();
    }

    const dt = $('#tablaProductos').DataTable({
        processing: true,
        serverSide: true,
        pageLength: 25,
        lengthMenu: [10, 25, 50, 100],
        ajax: {
            url: apiUrl,
            type: 'GET',
            data: function (d) { d.action = 'list'; }
        },
        order: [[0, 'desc']],
        columns: [
            { data: 'id' },
            { data: 'codigo' },
            { data: 'nombre' },
            { data: 'precio_compra', className: 'text-end', render: (v)=> Number(v).toFixed(2) },
            { data: 'precio_venta', className: 'text-end', render: (v)=> Number(v).toFixed(2) },
            { data: 'stock_actual', className: 'text-end' },
            { data: 'stock_minimo', className: 'text-end' },
            { data: 'fecha_vencimiento', render: (v)=> v ? v : '<span class="text-muted">—</span>' },
            { data: 'estado', render: (v)=> v == 1 ? '<span class="badge bg-success">Activo</span>' : '<span class="badge bg-secondary">Inactivo</span>' },
            {
                data: null,
                orderable: false,
                searchable: false,
                render: function (row) {
                    return `
                        <div class="d-flex gap-2">
                            <button class="btn btn-sm btn-theme-outline btn-edit" data-id="${row.id}">Editar</button>
                        </div>
                    `;
                }
            }
        ],
        language: {
            search: "Buscar:",
            lengthMenu: "Mostrar _MENU_",
            info: "Mostrando _START_ a _END_ de _TOTAL_",
            infoEmpty: "Sin datos",
            zeroRecords: "No se encontraron resultados",
            paginate: { first: "Primero", last: "Último", next: ">", previous: "<" }
        }
    });

    document.getElementById('btnNuevo').addEventListener('click', () => {
        clearError();
        document.getElementById('modalTitle').textContent = 'Nuevo Producto';
        fillForm(null);
        modal.show();
    });

    $('#tablaProductos').on('click', '.btn-edit', async function () {
        clearError();
        const id = this.getAttribute('data-id');
        document.getElementById('modalTitle').textContent = 'Editar Producto #' + id;
        try {
            const res = await fetch(apiUrl + '?action=get&id=' + encodeURIComponent(id), { credentials: 'same-origin' });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message || 'No se pudo cargar el producto');
            fillForm(json.data);
            modal.show();
        } catch (e) {
            alert(e.message || 'Error');
        }
    });

    form.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        clearError();
        const fd = new FormData(form);
        fd.append('action', 'save');

        const btn = document.getElementById('btnGuardar');
        btn.disabled = true;
        btn.textContent = 'Guardando...';

        try {
            const res = await fetch(apiUrl, {
                method: 'POST',
                body: fd,
                headers: { 'X-CSRF-Token': csrfToken },
                credentials: 'same-origin'
            });
            const json = await res.json();
            if (!json.ok) throw new Error(json.message || 'Error guardando');
            modal.hide();
            dt.ajax.reload(null, false);
        } catch (e) {
            showError(e.message || 'Error guardando');
        } finally {
            btn.disabled = false;
            btn.textContent = 'Guardar';
        }
    });
})();
</script>

