<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../models/Auth.php';
Auth::checkAccess();

$pageTitle = 'Acceso denegado - AbdiSoft CORE';
require_once __DIR__ . '/layout/header.php';
?>

<div class="container py-5">
    <div class="card p-4">
        <h2 class="title-strong mb-2">Acceso denegado</h2>
        <p class="text-muted mb-4">Tu rol no tiene permisos para acceder a esta sección.</p>
        <div class="d-flex gap-2">
            <a class="btn btn-primary" href="dashboard.php">Volver al Dashboard</a>
            <a class="btn btn-theme-outline" href="logout.php">Cambiar de usuario</a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>

