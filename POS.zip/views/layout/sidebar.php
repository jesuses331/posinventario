<?php
$active = $active ?? '';
$baseUrl = defined('BASE_URL') ? rtrim((string)BASE_URL, '/') . '/' : '/';
?>
<aside class="sidebar d-flex flex-column">
    <div class="brand">
        <div class="d-flex align-items-center">
            <div class="logo">A</div>
            <div>
                <div class="title">AbdiSoft CORE</div>
                <div class="subtitle"><?php echo htmlspecialchars($nombreNegocio ?? 'POS Multi-rubro'); ?></div>
            </div>
        </div>
    </div>

    <nav class="p-3 flex-grow-1">
        <div class="d-grid gap-1">
            <a class="nav-link <?php echo $active === 'dashboard' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($baseUrl . 'views/dashboard.php'); ?>">Dashboard</a>
            <a class="nav-link <?php echo $active === 'pos' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($baseUrl . 'views/modules/pos.php'); ?>">Nueva Venta (POS)</a>
            <a class="nav-link <?php echo $active === 'inventario' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($baseUrl . 'views/modules/inventario.php'); ?>">Inventario</a>
            <a class="nav-link <?php echo $active === 'reportes' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($baseUrl . 'views/modules/reportes.php'); ?>">Reportes</a>
            <a class="nav-link <?php echo $active === 'usuarios' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($baseUrl . 'views/modules/usuarios.php'); ?>">Usuarios</a>
            <a class="nav-link <?php echo $active === 'config' ? 'active' : ''; ?>" href="<?php echo htmlspecialchars($baseUrl . 'views/modules/configuracion.php'); ?>">Configuración</a>
        </div>
    </nav>

    <div class="p-3 border-top" style="border-color: var(--border) !important;">
        <button class="btn btn-sm w-100 mb-3 theme-toggle" type="button" id="themeToggle">Tema: Oscuro</button>
        <div class="d-flex align-items-center justify-content-between">
            <div>
                <div class="fw-bold title-strong" style="line-height:1.05">
                    <?php echo htmlspecialchars($_SESSION['user_nombre'] ?? ''); ?>
                </div>
                <div class="text-muted" style="font-size:.85rem">
                    <?php echo htmlspecialchars($_SESSION['user_rol'] ?? ''); ?>
                </div>
            </div>
            <a class="btn btn-theme-outline btn-sm" href="<?php echo htmlspecialchars($baseUrl . 'views/logout.php'); ?>">Salir</a>
        </div>
    </div>
</aside>

