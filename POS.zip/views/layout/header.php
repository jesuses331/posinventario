<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$baseUrl = defined('BASE_URL') ? rtrim((string)BASE_URL, '/') . '/' : '/';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle ?? 'AbdiSoft CORE'); ?></title>
    <script>
        (() => {
            const savedTheme = localStorage.getItem('pos-theme');
            if (savedTheme === 'light' || savedTheme === 'dark') {
                document.documentElement.setAttribute('data-theme', savedTheme);
            }
        })();
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="<?php echo htmlspecialchars($baseUrl . 'assets/css/main.css'); ?>" rel="stylesheet">
    <?php if (!empty($extraCss) && is_array($extraCss)): ?>
        <?php foreach ($extraCss as $href): ?>
            <link rel="stylesheet" href="<?php echo htmlspecialchars($href); ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>

