<?php

class Producto {
    private PDO $db;

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    public function countAll(string $search = ''): int {
        if ($search === '') {
            $stmt = $this->db->query("SELECT COUNT(*) AS c FROM productos");
            return (int)($stmt->fetch()['c'] ?? 0);
        }

        $stmt = $this->db->prepare("
            SELECT COUNT(*) AS c
            FROM productos
            WHERE codigo LIKE :q OR nombre LIKE :q OR lote LIKE :q
        ");
        $q = '%' . $search . '%';
        $stmt->execute([':q' => $q]);
        return (int)($stmt->fetch()['c'] ?? 0);
    }

    public function listDataTables(int $start, int $length, string $search, string $orderBy, string $orderDir): array {
        $allowedOrder = [
            'id' => 'id',
            'codigo' => 'codigo',
            'nombre' => 'nombre',
            'precio_compra' => 'precio_compra',
            'precio_venta' => 'precio_venta',
            'stock_actual' => 'stock_actual',
            'stock_minimo' => 'stock_minimo',
            'fecha_vencimiento' => 'fecha_vencimiento',
            'estado' => 'estado',
        ];
        $orderCol = $allowedOrder[$orderBy] ?? 'id';
        $dir = strtoupper($orderDir) === 'ASC' ? 'ASC' : 'DESC';

        $start = max(0, $start);
        $length = max(10, min(200, $length));

        $params = [];
        $where = '';
        if ($search !== '') {
            $where = "WHERE codigo LIKE :q OR nombre LIKE :q OR lote LIKE :q";
            $params[':q'] = '%' . $search . '%';
        }

        $sql = "
            SELECT id, codigo, nombre, precio_compra, precio_venta, stock_actual, stock_minimo,
                   factor_conversion, fecha_vencimiento, lote, estado
            FROM productos
            $where
            ORDER BY $orderCol $dir
            LIMIT :limit OFFSET :offset
        ";
        $stmt = $this->db->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v, PDO::PARAM_STR);
        }
        $stmt->bindValue(':limit', $length, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $start, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll() ?: [];
    }

    public function listSimple(int $offset, int $perPage, string $search, string $orderBy, string $orderDir): array {
        $allowedOrder = [
            'id' => 'id',
            'codigo' => 'codigo',
            'nombre' => 'nombre',
            'precio_venta' => 'precio_venta',
            'stock_actual' => 'stock_actual',
        ];
        $orderCol = $allowedOrder[$orderBy] ?? 'nombre';
        $dir = strtoupper($orderDir) === 'ASC' ? 'ASC' : 'DESC';

        $offset = max(0, $offset);
        $perPage = max(1, min(100, $perPage));

        $params = [];
        $where = '';
        if ($search !== '') {
            $where = "WHERE (codigo LIKE :q OR nombre LIKE :q OR lote LIKE :q) AND estado = 1";
            $params[':q'] = '%' . $search . '%';
        } else {
            $where = "WHERE estado = 1";
        }

        $sql = "
            SELECT id, codigo, nombre, precio_venta, stock_actual
            FROM productos
            $where
            ORDER BY $orderCol $dir
            LIMIT :limit OFFSET :offset
        ";
        $stmt = $this->db->prepare($sql);
        foreach ($params as $k => $v) {
            $stmt->bindValue($k, $v, PDO::PARAM_STR);
        }
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll() ?: [];
    }

    public function findById(int $id): ?array {
        $stmt = $this->db->prepare("
            SELECT id, codigo, nombre, precio_compra, precio_venta, stock_actual, stock_minimo,
                   factor_conversion, fecha_vencimiento, lote, estado
            FROM productos
            WHERE id = :id
            LIMIT 1
        ");
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function create(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO productos
                (codigo, nombre, precio_compra, precio_venta, stock_actual, stock_minimo, factor_conversion, fecha_vencimiento, lote, estado)
            VALUES
                (:codigo, :nombre, :precio_compra, :precio_venta, :stock_actual, :stock_minimo, :factor_conversion, :fecha_vencimiento, :lote, :estado)
        ");
        $stmt->execute([
            ':codigo' => $data['codigo'],
            ':nombre' => $data['nombre'],
            ':precio_compra' => $data['precio_compra'],
            ':precio_venta' => $data['precio_venta'],
            ':stock_actual' => $data['stock_actual'],
            ':stock_minimo' => $data['stock_minimo'],
            ':factor_conversion' => $data['factor_conversion'],
            ':fecha_vencimiento' => $data['fecha_vencimiento'],
            ':lote' => $data['lote'],
            ':estado' => $data['estado'],
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id, array $data): void {
        $stmt = $this->db->prepare("
            UPDATE productos SET
                codigo = :codigo,
                nombre = :nombre,
                precio_compra = :precio_compra,
                precio_venta = :precio_venta,
                stock_actual = :stock_actual,
                stock_minimo = :stock_minimo,
                factor_conversion = :factor_conversion,
                fecha_vencimiento = :fecha_vencimiento,
                lote = :lote,
                estado = :estado
            WHERE id = :id
            LIMIT 1
        ");
        $stmt->execute([
            ':id' => $id,
            ':codigo' => $data['codigo'],
            ':nombre' => $data['nombre'],
            ':precio_compra' => $data['precio_compra'],
            ':precio_venta' => $data['precio_venta'],
            ':stock_actual' => $data['stock_actual'],
            ':stock_minimo' => $data['stock_minimo'],
            ':factor_conversion' => $data['factor_conversion'],
            ':fecha_vencimiento' => $data['fecha_vencimiento'],
            ':lote' => $data['lote'],
            ':estado' => $data['estado'],
        ]);
    }
}

