(() => {
  const STORAGE_KEY = 'pos-theme';
  const root = document.documentElement;
  const toggle = document.getElementById('themeToggle');

  function getTheme() {
    const attrTheme = root.getAttribute('data-theme');
    if (attrTheme === 'light' || attrTheme === 'dark') return attrTheme;
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
    return 'dark';
  }

  function applyTheme(theme) {
    root.setAttribute('data-theme', theme);
    localStorage.setItem(STORAGE_KEY, theme);
    if (toggle) {
      toggle.textContent = theme === 'light' ? 'Tema: Claro' : 'Tema: Oscuro';
      toggle.setAttribute('aria-label', `Cambiar tema actual ${theme}`);
    }
  }

  if (toggle) {
    applyTheme(getTheme());
    toggle.addEventListener('click', () => {
      const next = getTheme() === 'dark' ? 'light' : 'dark';
      applyTheme(next);
    });
  } else {
    applyTheme(getTheme());
  }
})();

