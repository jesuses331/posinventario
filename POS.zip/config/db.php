<?php
// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'abdisoft_core');
define('DB_USER', 'root');
define('DB_PASS', ''); // Ajustar según tu configuración
define('DB_CHAR', 'utf8mb4');

// URL Base del proyecto (Ajustar según tu entorno)
define('BASE_URL', 'http://localhost/POS/');
