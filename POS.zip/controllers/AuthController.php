<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../models/Database.php';
require_once __DIR__ . '/../models/Auth.php';

class AuthController {
    private $db;
    private $auth;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->auth = new Auth($this->db);
    }

    public function handleLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';

            if (empty($email) || empty($password)) {
                return "Todos los campos son obligatorios.";
            }

            $result = $this->auth->login($email, $password);
            if ($result === true) {
                header("Location: dashboard.php");
                exit();
            } else {
                return $result;
            }
        }
        return null;
    }

    public function handleLogout() {
        $this->auth->logout();
    }
}
